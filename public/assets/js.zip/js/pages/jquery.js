let $  = require( 'jquery' );
