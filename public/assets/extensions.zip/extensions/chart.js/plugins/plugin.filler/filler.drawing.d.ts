export function _drawfill(ctx: any, source: any, area: any): void;
